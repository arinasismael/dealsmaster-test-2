AWS Elastic Beanstalk deployment

Use this package with a Node.js Elastic Beanstalk environment.

Platform: Node.js
Start command: npm start
Environment variable: NODE_ENV=production

The app listens on process.env.PORT automatically.
